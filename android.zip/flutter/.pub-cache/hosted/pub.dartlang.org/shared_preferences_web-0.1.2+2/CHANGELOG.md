# 0.1.2+2

* Remove unused onMethodCall method.

# 0.1.2+1

* Add an android/ folder with no-op implementation to workaround https://github.com/flutter/flutter/issues/46898.

# 0.1.2

* Bump lower constraint on Flutter version.
* Add stub podspec file.

# 0.1.1

* Adds a `shared_preferences_macos` package.

# 0.1.0+1

- Remove the deprecated `author:` field from pubspec.yaml
- Require Flutter SDK 1.10.0 or greater.

# 0.1.0

- Initial release.
