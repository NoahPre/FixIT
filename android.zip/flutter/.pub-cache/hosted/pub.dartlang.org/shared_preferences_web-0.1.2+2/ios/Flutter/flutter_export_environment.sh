#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/martinjurk/Documents/development/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/martinjurk/Documents/development/flutter/.pub-cache/hosted/pub.dartlang.org/shared_preferences_web-0.1.2+2"
export "FLUTTER_TARGET=lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "OTHER_LDFLAGS=$(inherited) -framework Flutter"
export "FLUTTER_FRAMEWORK_DIR=/Users/martinjurk/Documents/development/flutter/bin/cache/artifacts/engine/ios"
export "FLUTTER_BUILD_NAME=0.1.2"
export "FLUTTER_BUILD_NUMBER=2"
