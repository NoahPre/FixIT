//
//  KeyboardVisibilityHandler.h
//  Runner
//
//  Created by admin on 07/11/2018.
//  Copyright © 2018 The Chromium Authors. All rights reserved.
//

#ifndef KeyboardVisibilityPlugin_h
#define KeyboardVisibilityPlugin_h

#import <Flutter/Flutter.h>

@interface FLTKeyboardVisibilityPlugin : NSObject<FlutterPlugin>
@end

#endif /* CompassHandler_h */
