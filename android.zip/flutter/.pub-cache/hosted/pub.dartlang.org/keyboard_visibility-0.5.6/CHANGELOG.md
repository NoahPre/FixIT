## [0.5.6] - 13-05-2019

* added null check in Android layout callback
* changed behavior on dispose
* catching exceptions if callbacks are not unsubscribed properly

## [0.5.5] - 11-05-2019

* Changed README.md and formatted Dart code

## [0.5.4] - 11-05-2019

* Fixed plugin registration bug

## [0.5.3] - 09-05-2019

* Fixed exception call bug on dispose
* Change behavior of plugin registration

## [0.5.2] - 12-03-2019

* Fixed possible bug on dispose
* On iOS the keyboard pop up message is already being sent when keyboard starts popping up

## [0.5.1] - 06-01-2019

* Fixed bug when using multiple listeners on same page

## [0.5.0] - 06-12-2018

* Initial release, working on Android and iOS
