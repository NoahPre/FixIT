//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <keyboard_visibility/KeyboardVisibilityPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FLTKeyboardVisibilityPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTKeyboardVisibilityPlugin"]];
}

@end
